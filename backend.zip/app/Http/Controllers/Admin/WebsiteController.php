<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Website;
use App\Models\Tenant;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Artisan;
use App\Jobs\IndexWebsiteKnowledgeJob;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class WebsiteController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();

        $query = Website::with('tenant')
            ->withCount([
                'knowledgePages',
                'knowledgeChunks',
                'conversations',
                'leads',
            ]);

        if (!$user->isSuperAdmin()) {
            $query->where('tenant_id', $user->tenant_id);
        }

        if ($request->filled('search')) {
            $search = $request->search;

            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('domain', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            if ($request->status === 'active') {
                $query->where('is_active', true);
            }

            if ($request->status === 'inactive') {
                $query->where('is_active', false);
            }
        }

        $websites = $query
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.websites.index', compact('websites'));
    }

    public function create()
    {
        $user = auth()->user();

        $tenants = collect();

        if ($user->isSuperAdmin()) {
            $tenants = Tenant::orderBy('name')->get();
        }

        $themes = config('chatbot.themes');

        return view('admin.websites.create', compact('tenants', 'themes'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();

        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'domain' => ['required', 'string', 'max:1000'],
            'verify_domain' => ['nullable', 'boolean'],
            'is_active' => ['nullable', 'boolean'],
            'chatbot_name' => ['nullable', 'string', 'max:100'],
            'chatbot_theme' => [
                'required',
                'string',
                Rule::in(array_keys(config('chatbot.themes'))),
            ],
            'chatbot_avatar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp,svg', 'max:2048'],
            'chatbot_instructions' => ['nullable', 'string', 'max:10000'],
        ];

        if ($user->isSuperAdmin()) {
            $rules['tenant_id'] = ['required', 'exists:tenants,id'];
        }

        $validated = $request->validate($rules);

        $tenantId = $user->isSuperAdmin()
            ? $validated['tenant_id']
            : $user->tenant_id;

        if (!$tenantId) {
            return redirect()
                ->back()
                ->withInput()
                ->withErrors([
                    'tenant_id' => 'No tenant is assigned to this user. Please assign a tenant or use a super admin account.',
                ]);
        }

        $domain = $this->normalizeDomain($validated['domain']);
        $avatarPath = null;

        if ($request->hasFile('chatbot_avatar')) {
            $avatarPath = $request->file('chatbot_avatar')
                ->store('chatbot-avatars', 'public');
        }
        $website = Website::create([
            'tenant_id' => $tenantId,
            'name' => $validated['name'],
            'domain' => $domain,
            'verify_domain' => $request->boolean('verify_domain'),
            'is_active' => $request->boolean('is_active', true),
            'embed_token' => Str::random(48),
            'indexing_status' => 'pending',

            'chatbot_name' => $validated['chatbot_name'] ?: $validated['name'] . ' Assistant',
            'chatbot_theme' => $validated['chatbot_theme'] ?? config('chatbot.default_theme'),
            'chatbot_avatar' => $avatarPath,
            'chatbot_instructions' => $validated['chatbot_instructions'] ?? null,
        ]);

        IndexWebsiteKnowledgeJob::dispatch($website->id, 100);

        return redirect()
            ->route('admin.websites.show', $website)
            ->with('success', 'Website created successfully. Crawling and indexing has started in the background.');
    }

    public function show(Website $website)
    {
        $this->authorizeWebsiteAccess($website);

        $website->load([
            'tenant',
            'knowledgePages' => function ($query) {
                $query->latest()->take(20);
            },
        ]);

        $website->loadCount([
            'knowledgePages',
            'knowledgeChunks',
            'conversations',
            'leads',
        ]);

        return view('admin.websites.show', compact('website'));
    }

    public function edit(Website $website)
    {
        $this->authorizeWebsiteAccess($website);

        $tenants = collect();

        if (auth()->user()->isSuperAdmin()) {
            $tenants = Tenant::orderBy('name')->get();
        }

        $themes = config('chatbot.themes');

        return view('admin.websites.edit', compact('website', 'tenants', 'themes'));
    }

    public function update(Request $request, Website $website)
    {
        $this->authorizeWebsiteAccess($website);

        $user = auth()->user();

        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'domain' => ['required', 'string', 'max:1000'],
            'verify_domain' => ['nullable', 'boolean'],
            'is_active' => ['nullable', 'boolean'],
            'chatbot_name' => ['nullable', 'string', 'max:100'],
            'chatbot_theme' => [
                'required',
                'string',
                Rule::in(array_keys(config('chatbot.themes'))),
            ],
            'chatbot_avatar' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp,svg', 'max:2048'],
            'chatbot_instructions' => ['nullable', 'string', 'max:10000'],
        ];

        if ($user->isSuperAdmin()) {
            $rules['tenant_id'] = ['required', 'exists:tenants,id'];
        }

        $validated = $request->validate($rules);

        $website->name = $validated['name'];
        $website->domain = $this->normalizeDomain($validated['domain']);
        $website->verify_domain = $request->boolean('verify_domain');
        $website->is_active = $request->boolean('is_active');

        if ($user->isSuperAdmin()) {
            $website->tenant_id = $validated['tenant_id'];
        }
        $website->chatbot_name = $validated['chatbot_name'] ?: $validated['name'] . ' Assistant';
        $website->chatbot_theme = $validated['chatbot_theme'];
        $website->chatbot_instructions = $validated['chatbot_instructions'] ?? null;

        if ($request->hasFile('chatbot_avatar')) {
            if ($website->chatbot_avatar) {
                Storage::disk('public')->delete($website->chatbot_avatar);
            }

            $website->chatbot_avatar = $request->file('chatbot_avatar')
                ->store('chatbot-avatars', 'public');
        }
        $website->save();

        return redirect()
            ->route('admin.websites.show', $website)
            ->with('success', 'Website updated successfully.');
    }

    public function regenerateToken(Website $website)
    {
        $this->authorizeWebsiteAccess($website);

        $website->embed_token = Str::random(48);
        $website->save();

        return redirect()
            ->back()
            ->with('success', 'Embed token regenerated successfully. Update the embed code on the client website.');
    }

    public function indexKnowledge(Request $request, Website $website)
    {
        $this->authorizeWebsiteAccess($website);

        if (in_array($website->indexing_status, ['pending', 'processing'])) {
            return redirect()
                ->back()
                ->with('success', 'Indexing is already running for this website.');
        }

        $request->validate([
            'limit' => ['nullable', 'integer', 'min:1', 'max:10000'],
        ]);

        $limit = $request->filled('limit')
                ? (int) $request->input('limit')
                : null;

       $website->update([
            'indexing_status' => 'pending',
            'indexing_started_at' => null,
            'indexing_completed_at' => null,
            'indexing_error' => null,
        ]);

        IndexWebsiteKnowledgeJob::dispatch($website->id, $limit);

        return redirect()
            ->back()
            ->with('success', 'Website knowledge indexing started.');
    }

    private function authorizeWebsiteAccess(Website $website): void
    {
        $user = auth()->user();

        if ($user->isSuperAdmin()) {
            return;
        }

        if ($website->tenant_id !== $user->tenant_id) {
            abort(403, 'Unauthorized website access.');
        }
    }

    private function normalizeDomain(string $domain): string
    {
        $domain = trim($domain);

        $domain = rtrim($domain, '/');

        return $domain;
    }
}

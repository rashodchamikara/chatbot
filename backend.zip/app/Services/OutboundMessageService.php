<?php

namespace App\Omnichannel\Services;

use App\Models\ContactIdentity;
use App\Models\Conversation;
use App\Models\Message;
use App\Omnichannel\ChannelManager;
use App\Omnichannel\Data\OutboundMessageData;
use App\Omnichannel\Data\SendResult;
use Illuminate\Support\Facades\DB;
use RuntimeException;
use Throwable;

class OutboundMessageService
{
    public function __construct(
        protected ChannelManager $channelManager
    ) {
    }

    /**
     * Send an outbound message for an existing conversation.
     */
    public function send(
        Conversation $conversation,
        string $body,
        string $senderType = 'agent',
        ?int $senderUserId = null,
        bool $isAiGenerated = false,
        array $attachments = [],
        array $metadata = [],
        ?string $replyToExternalId = null,
    ): Message {
        /*
        |--------------------------------------------------------------------------
        | 1. Validate conversation
        |--------------------------------------------------------------------------
        */

        if (!$conversation->channel_connection_id) {
            throw new RuntimeException(
                'Conversation does not have a channel connection.'
            );
        }

        if (!$conversation->contact_id) {
            throw new RuntimeException(
                'Conversation does not have a contact.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 2. Load channel connection
        |--------------------------------------------------------------------------
        */

        $conversation->loadMissing(
            'channelConnection'
        );

        $connection =
            $conversation->channelConnection;

        if (!$connection) {
            throw new RuntimeException(
                'Channel connection could not be found.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 3. Tenant isolation check
        |--------------------------------------------------------------------------
        */

        if (
            (int) $conversation->tenant_id !==
            (int) $connection->tenant_id
        ) {
            throw new RuntimeException(
                'Conversation and channel connection belong to different tenants.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 4. Resolve contact identity
        |--------------------------------------------------------------------------
        |
        | We need the provider-specific customer ID:
        |
        | WhatsApp    -> phone/provider user ID
        | Messenger   -> PSID
        | Instagram   -> Instagram scoped user ID
        | Telegram    -> chat/user ID
        | Email       -> email identity
        |
        */

        $identity = ContactIdentity::query()
            ->where(
                'tenant_id',
                $conversation->tenant_id
            )
            ->where(
                'contact_id',
                $conversation->contact_id
            )
            ->where(
                'channel_connection_id',
                $connection->id
            )
            ->first();

        if (!$identity) {
            throw new RuntimeException(
                'No contact identity exists for this conversation and channel.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | 5. Create local pending message
        |--------------------------------------------------------------------------
        |
        | Save before contacting the external provider.
        |
        | This ensures failed messages are still visible and traceable.
        |
        */

        $message = DB::transaction(
            function () use (
                $conversation,
                $connection,
                $body,
                $senderType,
                $senderUserId,
                $isAiGenerated,
                $attachments,
                $metadata,
                $replyToExternalId
            ): Message {
                $message = new Message();

                $message->conversation_id =
                    $conversation->id;

                $message->channel_connection_id =
                    $connection->id;

                $message->sender_user_id =
                    $senderUserId;

                $message->external_reply_to_id =
                    $replyToExternalId;

                $message->direction =
                    'outbound';

                $message->sender_type =
                    $senderType;

                $message->message_type =
                    empty($attachments)
                        ? 'text'
                        : 'attachment';

                /*
                 * Existing message body column.
                 */
                $message->message =
                    $body;

                $message->payload = [
                    'attachments' => $attachments,
                    'metadata' => $metadata,
                ];

                $message->status =
                    'pending';

                $message->is_ai_generated =
                    $isAiGenerated;

                $message->save();

                return $message;
            }
        );

        /*
        |--------------------------------------------------------------------------
        | 6. Build provider-neutral outbound DTO
        |--------------------------------------------------------------------------
        */

        $outbound = new OutboundMessageData(
            externalUserId:
                $identity->external_user_id,

            externalThreadId:
                $conversation->external_thread_id,

            type:
                $message->message_type,

            body:
                $body,

            attachments:
                $attachments,

            metadata:
                array_merge(
                    $metadata,
                    [
                        'conversation_id' =>
                            $conversation->id,

                        'message_id' =>
                            $message->id,
                    ]
                ),

            replyToExternalId:
                $replyToExternalId,
        );

        try {
            /*
            |--------------------------------------------------------------------------
            | 7. Resolve correct adapter
            |--------------------------------------------------------------------------
            */

            $adapter =
                $this->channelManager->adapter(
                    $connection->type
                );

            /*
            |--------------------------------------------------------------------------
            | 8. Send through provider
            |--------------------------------------------------------------------------
            */

            $result = $adapter->send(
                $connection,
                $outbound
            );

            /*
            |--------------------------------------------------------------------------
            | 9. Validate result
            |--------------------------------------------------------------------------
            */

            if (!$result instanceof SendResult) {
                throw new RuntimeException(
                    'Channel adapter returned an invalid send result.'
                );
            }

            /*
            |--------------------------------------------------------------------------
            | 10. Update successfully sent message
            |--------------------------------------------------------------------------
            */

            DB::transaction(
                function () use (
                    $message,
                    $conversation,
                    $result
                ): void {
                    $message->external_message_id =
                        $result->externalMessageId;

                    $message->status =
                        $result->status;

                    /*
                     * Keep provider response for diagnostics.
                     */
                    $payload =
                        is_array($message->payload)
                            ? $message->payload
                            : [];

                    $payload['provider_response'] =
                        $result->rawResponse;

                    $message->payload =
                        $payload;

                    if (
                        in_array(
                            $result->status,
                            [
                                'sent',
                                'delivered',
                                'success',
                            ],
                            true
                        )
                    ) {
                        $message->sent_at =
                            now();
                    }

                    $message->save();

                    /*
                    |--------------------------------------------------------------------------
                    | Conversation timestamps
                    |--------------------------------------------------------------------------
                    */

                    $conversation->last_message_at =
                        now();

                    /*
                     * first_response_at represents the first
                     * outbound response after customer contact.
                     */
                    if (
                        !$conversation->first_response_at
                    ) {
                        $conversation->first_response_at =
                            now();
                    }

                    $conversation->save();
                }
            );

            return $message->fresh();
        } catch (Throwable $exception) {


            $message->status =
                'failed';

            $message->error_message =
                $exception->getMessage();

            $message->save();

            throw $exception;
        }
    }
}
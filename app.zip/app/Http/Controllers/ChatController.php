<?php

namespace App\Http\Controllers;

use App\Events\ConversationMessageCreated;
use App\Events\ConversationModeChanged;
use App\Events\LiveAgentRequested;
use App\Events\OmnichannelMessageChanged;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Website;
use App\Services\AgentAvailabilityService;
use App\Services\Knowledge\KnowledgeContextBuilder;
use App\Services\Knowledge\KnowledgeRetriever;
use App\Services\LeadCaptureService;
use App\Services\Omnichannel\ChannelManager;
use App\Services\Omnichannel\InboundMessageService;
use App\Services\Omnichannel\OutboundMessageService;
use App\Services\Omnichannel\WebsiteConversationResolver;
use App\Services\SalesBrainService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

class ChatController extends Controller
{
    public function __construct(
        private readonly KnowledgeRetriever $knowledgeRetriever,
        private readonly KnowledgeContextBuilder $contextBuilder,
        private readonly ChannelManager $channelManager,
        private readonly InboundMessageService $inboundMessageService,
        private readonly OutboundMessageService $outboundMessageService,
        private readonly WebsiteConversationResolver $websiteConversationResolver,
    ) {
    }

    /**
     * Handle a message sent from the website widget.
     */
    public function message(
        Request $request,
        SalesBrainService $brain,
        LeadCaptureService $leadCaptureService
    ): JsonResponse {
        /*
        |--------------------------------------------------------------------------
        | Validate widget request
        |--------------------------------------------------------------------------
        */

        $validated = $request->validate([
            'message' => [
                'required',
                'string',
                'max:5000',
            ],

            'visitor_id' => [
                'required',
                'string',
                'max:255',
            ],

            /*
             * Optional for backwards compatibility.
             *
             * Existing widget versions do not need to send this.
             * Future versions can send it for stronger idempotency.
             */
            'client_message_id' => [
                'nullable',
                'string',
                'max:100',
            ],
        ]);

        /*
        |--------------------------------------------------------------------------
        | Resolve Website from embed-token middleware
        |--------------------------------------------------------------------------
        */

        $website = $this->resolveWebsite(
            $request
        );

        if (!$website) {
            return response()->json([
                'message' =>
                    'Website could not be resolved from the embed token.',
            ], 404);
        }

        /*
        |--------------------------------------------------------------------------
        | Resolve Website omnichannel conversation
        |--------------------------------------------------------------------------
        |
        | This ensures:
        |
        | Website
        |   -> AI Agent
        |   -> ChannelConnection
        |   -> Contact
        |   -> ContactIdentity
        |   -> Conversation
        |
        | Legacy visitor_id and website_id are preserved.
        |--------------------------------------------------------------------------
        */

        try {
            $conversation =
                $this
                    ->websiteConversationResolver
                    ->resolve(
                        $website,
                        $validated['visitor_id']
                    );

            $conversation->load(
                'channelConnection'
            );

            $connection =
                $conversation->channelConnection;

            if (!$connection) {
                throw new RuntimeException(
                    'Website channel connection could not be resolved.'
                );
            }
        } catch (RuntimeException $exception) {
            Log::error(
                'Website omnichannel conversation resolution failed.',
                [
                    'website_id' =>
                        $website->id,

                    'visitor_id' =>
                        $validated['visitor_id'],

                    'error' =>
                        $exception->getMessage(),
                ]
            );

            return response()->json([
                'message' =>
                    $exception->getMessage(),
            ], 409);
        }

        /*
        |--------------------------------------------------------------------------
        | Build conversation history
        |--------------------------------------------------------------------------
        |
        | We build history BEFORE saving the current visitor message.
        |--------------------------------------------------------------------------
        */

        $history =
            Message::query()
                ->where(
                    'conversation_id',
                    $conversation->id
                )
                ->where(
                    function ($query): void {
                        $query
                            ->where(
                                'is_system',
                                false
                            )
                            ->orWhereNull(
                                'is_system'
                            );
                    }
                )
                ->where(
                    function ($query): void {
                        $query
                            ->whereIn(
                                'sender',
                                [
                                    'visitor',
                                    'user',
                                    'ai',
                                    'assistant',
                                    'agent',
                                ]
                            )
                            ->orWhereIn(
                                'sender_type',
                                [
                                    'contact',
                                    'ai',
                                    'agent',
                                ]
                            );
                    }
                )
                ->latest('id')
                ->limit(10)
                ->get()
                ->reverse()
                ->map(
                    function (
                        Message $message
                    ): array {
                        $isVisitor =
                            $message->direction === 'inbound'
                            ||
                            $message->sender_type === 'contact'
                            ||
                            in_array(
                                $message->sender,
                                [
                                    'visitor',
                                    'user',
                                ],
                                true
                            );

                        return [
                            'role' =>
                                $isVisitor
                                    ? 'user'
                                    : 'assistant',

                            'content' =>
                                $message->message,
                        ];
                    }
                )
                ->values()
                ->toArray();

        $connection =
            $this->websiteConversationResolver
                ->resolveConnection(
                    $website
                );

        /*
        |--------------------------------------------------------------------------
        | Resolve WebsiteAdapter and normalize inbound widget request
        |--------------------------------------------------------------------------
        */

        $adapter =
            $this
                ->channelManager
                ->forConnection(
                    $connection
                );

        $inbound =
            $adapter->parseInbound(
                $connection,
                $request
            );

        if (!$inbound) {
            return response()->json([
                'message' =>
                    'The website message could not be normalized.',
            ], 422);
        }

        /*
        |--------------------------------------------------------------------------
        | Persist inbound message through common omnichannel service
        |--------------------------------------------------------------------------
        */

        $visitorMessage =
            $this
                ->inboundMessageService
                ->handle(
                    $inbound
                );

        $visitorMessage->load(
            'conversation'
        );

        $conversation =
            $visitorMessage->conversation;

        /*
        |--------------------------------------------------------------------------
        | Do not rebroadcast inbound visitor messages to the public widget channel
        |--------------------------------------------------------------------------
        |
        | The widget already renders the visitor's message locally. Broadcasting
        | this inbound row through ConversationMessageCreated makes the widget
        | receive its own message as though it were a reply.
        |
        | InboundMessageService still publishes OmnichannelMessageChanged to the
        | tenant/admin inbox, so operators continue to receive inbound messages.
        |--------------------------------------------------------------------------
        */

        $conversation->refresh();

        /*
        |--------------------------------------------------------------------------
        | Live-agent mode
        |--------------------------------------------------------------------------
        |
        | When the conversation is waiting for or currently handled by
        | a human agent, AI must not generate another reply.
        |--------------------------------------------------------------------------
        */

        if (
            in_array(
                $conversation->mode,
                [
                    'live_waiting',
                    'live',
                ],
                true
            )
        ) {
            return response()->json([
                'success' =>
                    true,

                'reply' =>
                    null,

                'reply_message' =>
                    null,

                'mode' =>
                    $conversation->mode,

                'conversation_id' =>
                    $conversation->id,

                'conversation_channel' =>
                    $this->conversationChannel(
                        $conversation
                    ),

                'message' =>
                    $conversation->mode === 'live'
                        ? 'Message sent to the live agent.'
                        : 'Message sent. Please wait for a live agent.',
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Lead capture
        |--------------------------------------------------------------------------
        */

        $leadResult =
            $leadCaptureService
                ->processMessage(
                    $website,
                    $conversation,
                    $validated['message']
                );

        $lead =
            $leadResult['lead']
            ?? null;

        $leadStage =
            $leadResult['lead_stage']
            ?? $conversation->lead_stage
            ?? 'discovery';

        $nextLeadQuestion =
            $leadResult['next_question']
            ?? null;

        /*
        |--------------------------------------------------------------------------
        | Knowledge retrieval
        |--------------------------------------------------------------------------
        */

        $knowledgeResults = [];

        $knowledgeContext =
            'No relevant knowledge was found for this question.';

        try {
            $knowledgeResults =
                $this
                    ->knowledgeRetriever
                    ->retrieve(
                        $website,
                        $validated['message']
                    );

            $knowledgeContext =
                $this
                    ->contextBuilder
                    ->build(
                        $knowledgeResults
                    );
        } catch (Throwable $exception) {
            /*
             * Chat should continue even when knowledge retrieval fails.
             */
            Log::error(
                'Knowledge retrieval failed.',
                [
                    'website_id' =>
                        $website->id,

                    'conversation_id' =>
                        $conversation->id,

                    'error' =>
                        $exception->getMessage(),
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Generate AI response
        |--------------------------------------------------------------------------
        */

        try {
            $aiText =
                $brain->analyze(
                    $validated['message'],
                    $website,
                    $history,
                    $lead,
                    $leadStage,
                    $nextLeadQuestion,
                    $knowledgeContext
                );
        } catch (Throwable $exception) {
            Log::error(
                'AI response generation failed.',
                [
                    'website_id' =>
                        $website->id,

                    'conversation_id' =>
                        $conversation->id,

                    'error' =>
                        $exception->getMessage(),
                ]
            );

            return response()->json([
                'success' =>
                    false,

                'message' =>
                    'The AI assistant could not generate a response right now.',

                'conversation_id' =>
                    $conversation->id,

                'conversation_channel' =>
                    $this->conversationChannel(
                        $conversation
                    ),
            ], 500);
        }

        $aiText =
            trim(
                (string)
                $aiText
            );

        if ($aiText === '') {
            $aiText =
                'Sorry, I could not generate a response right now.';
        }

        /*
        |--------------------------------------------------------------------------
        | Persist and deliver AI response
        |--------------------------------------------------------------------------
        |
        | AI replies now use the COMMON OutboundMessageService.
        |
        | WebsiteAdapter handles delivery through the existing Reverb
        | ConversationMessageCreated event.
        |--------------------------------------------------------------------------
        */

        try {
            $aiMessage =
                $this
                    ->outboundMessageService
                    ->send(
                        conversation:
                            $conversation,

                        body:
                            $aiText,

                        senderType:
                            'ai',

                        senderUserId:
                            null,

                        isAiGenerated:
                            true,

                        attachments:
                            [],

                        metadata: [
                            'source' =>
                                'website_ai',
                        ],
                    );
        } catch (Throwable $exception) {
            Log::error(
                'Website AI outbound delivery failed.',
                [
                    'website_id' =>
                        $website->id,

                    'conversation_id' =>
                        $conversation->id,

                    'error' =>
                        $exception->getMessage(),
                ]
            );

            return response()->json([
                'success' =>
                    false,

                'message' =>
                    'The AI response could not be delivered.',

                'conversation_id' =>
                    $conversation->id,

                'conversation_channel' =>
                    $this->conversationChannel(
                        $conversation
                    ),
            ], 500);
        }

        /*
        |--------------------------------------------------------------------------
        | Return response expected by existing widget
        |--------------------------------------------------------------------------
        */

        return response()->json([
            'success' =>
                true,

            'reply' =>
                $aiMessage->message,

            'reply_message' =>
                $this->formatMessage(
                    $aiMessage
                ),

            'mode' =>
                $conversation->mode
                ?: 'ai',

            'conversation_id' =>
                $conversation->id,

            'conversation_channel' =>
                $this->conversationChannel(
                    $conversation
                ),

            'lead' =>
                $lead
                    ? [
                        'id' =>
                            $lead->id,

                        'name' =>
                            $lead->name,

                        'email' =>
                            $lead->email,

                        'phone' =>
                            $lead->phone,

                        'country' =>
                            $lead->country,

                        'preferred_contact_time' =>
                            $lead->preferred_contact_time,

                        'product_interest' =>
                            $lead->product_interest,

                        'lead_score' =>
                            $lead->lead_score,

                        'status' =>
                            $lead->status,
                    ]
                    : null,

            'lead_stage' =>
                $leadStage,
        ]);
    }

    /**
     * Return public widget configuration.
     */
    public function config(
        Request $request,
        AgentAvailabilityService $agentAvailability
    ): JsonResponse {
        $website =
            $this->resolveWebsite(
                $request
            );

        if (!$website) {
            return response()->json([
                'message' =>
                    'Website could not be resolved from the embed token.',
            ], 404);
        }

        $themes =
            config(
                'chatbot.themes',
                []
            );

        $defaultThemeKey =
            config(
                'chatbot.default_theme',
                'blue'
            );

        $fallbackTheme = [
            'label' =>
                'Blue',

            'primary' =>
                '#2563eb',

            'secondary' =>
                '#eff6ff',

            'text' =>
                '#ffffff',
        ];

        $themeKey =
            $website->chatbot_theme
            ?: $defaultThemeKey;

        $theme =
            $themes[$themeKey]
            ?? $themes[$defaultThemeKey]
            ?? $fallbackTheme;

        $realtimeKey =
            config(
                'chatbot.realtime.key'
            );

        $realtimeHost =
            config(
                'chatbot.realtime.host'
            );

        return response()->json([
            'website_id' =>
                $website->id,

            'chatbot_name' =>
                $website->chatbot_name
                ?: (
                    $website->name
                    . ' Assistant'
                ),

            'theme' => [
                'key' =>
                    $themeKey,

                'primary' =>
                    $theme['primary']
                    ?? $fallbackTheme['primary'],

                'secondary' =>
                    $theme['secondary']
                    ?? $fallbackTheme['secondary'],

                'text' =>
                    $theme['text']
                    ?? $fallbackTheme['text'],
            ],

            'avatar_url' =>
                $website->chatbot_avatar
                    ? asset(
                        'storage/'
                        . ltrim(
                            $website->chatbot_avatar,
                            '/'
                        )
                    )
                    : null,

            'live_agent_available' =>
                $agentAvailability
                    ->hasOnlineAgent(
                        $website
                    ),

            'realtime' => [
                'enabled' =>
                    filled($realtimeKey)
                    &&
                    filled($realtimeHost)
                    &&
                    filled(
                        $website->realtime_token
                    ),

                'key' =>
                    $realtimeKey,

                'host' =>
                    $realtimeHost,

                'port' =>
                    (int)
                    config(
                        'chatbot.realtime.port',
                        443
                    ),

                'scheme' =>
                    config(
                        'chatbot.realtime.scheme',
                        'https'
                    ),

                'website_channel' =>
                    filled(
                        $website->realtime_token
                    )
                        ? 'website.'
                            . $website->realtime_token
                        : null,
            ],
        ]);
    }

    /**
     * Return previous messages for a website visitor.
     */
    public function history(
        Request $request
    ): JsonResponse {
        $validated =
            $request->validate([
                'visitor_id' => [
                    'required',
                    'string',
                    'max:255',
                ],

                'limit' => [
                    'nullable',
                    'integer',
                    'min:1',
                    'max:100',
                ],
            ]);

        $website =
            $this->resolveWebsite(
                $request
            );

        if (!$website) {
            return response()->json([
                'message' =>
                    'Website could not be resolved from the embed token.',
            ], 404);
        }

        $limit =
            (int)
            (
                $validated['limit']
                ?? 50
            );

        /*
         * History lookup should not create
         * a brand-new empty conversation.
         */
        $conversation =
            $this->findWebsiteConversation(
                $website,
                $validated['visitor_id']
            );

        if (!$conversation) {
            return response()->json([
                'conversation_id' =>
                    null,

                'conversation_channel' =>
                    null,

                'mode' =>
                    'ai',

                'messages' =>
                    [],
            ]);
        }

        $messages =
            $conversation
                ->messages()
                ->with('user')
                ->latest('id')
                ->limit($limit)
                ->get()
                ->sortBy('id')
                ->values()
                ->map(
                    function (
                        Message $message
                    ): array {
                        return
                            $this->formatMessage(
                                $message
                            );
                    }
                );

        return response()->json([
            'conversation_id' =>
                $conversation->id,

            'conversation_channel' =>
                $this->conversationChannel(
                    $conversation
                ),

            'mode' =>
                $conversation->mode
                ?: 'ai',

            'messages' =>
                $messages,
        ]);
    }

    /**
     * Visitor requests a human/live agent.
     */
    public function requestLiveAgent(
        Request $request,
        AgentAvailabilityService $agentAvailability
    ): JsonResponse {
        $validated =
            $request->validate([
                'visitor_id' => [
                    'required',
                    'string',
                    'max:255',
                ],
            ]);

        $website =
            $this->resolveWebsite(
                $request
            );

        if (!$website) {
            return response()->json([
                'message' =>
                    'Website could not be resolved.',
            ], 404);
        }

        if (
            !$agentAvailability
                ->hasOnlineAgent(
                    $website
                )
        ) {
            return response()->json([
                'message' =>
                    'No live agent is currently available.',

                'available' =>
                    false,
            ], 409);
        }

        /*
         * Live-agent request is a genuine visitor
         * interaction, so creating/upgrading the
         * omnichannel conversation is appropriate.
         */

        try {
            $conversation =
                $this
                    ->websiteConversationResolver
                    ->resolve(
                        $website,
                        $validated['visitor_id']
                    );
        } catch (RuntimeException $exception) {
            return response()->json([
                'message' =>
                    $exception->getMessage(),
            ], 409);
        }

        $result =
            DB::transaction(
                function () use (
                    $conversation
                ): array {
                    $conversation =
                        Conversation::query()
                            ->lockForUpdate()
                            ->findOrFail(
                                $conversation->id
                            );

                    if (
                        $conversation->mode
                        === 'live'
                    ) {
                        return [
                            'conversation' =>
                                $conversation,

                            'message' =>
                                null,

                            'already_requested' =>
                                true,

                            'response_message' =>
                                'A live agent is already handling this conversation.',
                        ];
                    }

                    if (
                        $conversation->mode
                        === 'live_waiting'
                    ) {
                        return [
                            'conversation' =>
                                $conversation,

                            'message' =>
                                null,

                            'already_requested' =>
                                true,

                            'response_message' =>
                                'A live agent has already been notified. Please wait a moment.',
                        ];
                    }

                    $conversation->update([
                        'mode' =>
                            'live_waiting',

                        /*
                         * Existing website live-chat assignment.
                         */
                        'assigned_agent_id' =>
                            null,

                        /*
                         * New common omnichannel assignment.
                         */
                        'assigned_user_id' =>
                            null,

                        'live_requested_at' =>
                            now(),

                        'live_started_at' =>
                            null,

                        'live_ended_at' =>
                            null,
                    ]);

                    /*
                     * System message remains local but now
                     * also includes omnichannel fields.
                     */
                    $systemMessage =
                        Message::create([
                            'conversation_id' =>
                                $conversation->id,

                            'channel_connection_id' =>
                                $conversation
                                    ->channel_connection_id,

                            'user_id' =>
                                null,

                            'sender_user_id' =>
                                null,

                            'sender' =>
                                'system',

                            'sender_type' =>
                                'system',

                            'direction' =>
                                'outbound',

                            'message_type' =>
                                'text',

                            'status' =>
                                'sent',

                            'is_ai_generated' =>
                                false,

                            'is_system' =>
                                true,

                            'sent_at' =>
                                now(),

                            'message' =>
                                'Visitor requested a live agent.',
                        ]);

                    return [
                        'conversation' =>
                            $conversation->fresh(),

                        'message' =>
                            $systemMessage,

                        'already_requested' =>
                            false,

                        'response_message' =>
                            'A live agent has been notified. Please wait a moment.',
                    ];
                }
            );

        $conversation =
            $result['conversation'];

        /*
        |--------------------------------------------------------------------------
        | Broadcast live-agent request
        |--------------------------------------------------------------------------
        */

        if (
            !$result['already_requested']
        ) {
            broadcast(
                new ConversationMessageCreated(
                    $result['message']
                )
            );

            /*
             * Also publish to the new omnichannel inbox.
             */
            OmnichannelMessageChanged::dispatch(
                $result['message'],
                'created'
            );

            broadcast(
                new ConversationModeChanged(
                    $conversation
                )
            );

            broadcast(
                new LiveAgentRequested(
                    $conversation
                )
            );
        }

        return response()->json([
            'success' =>
                true,

            'message' =>
                $result[
                    'response_message'
                ],

            'conversation_id' =>
                $conversation->id,

            'conversation_channel' =>
                $this->conversationChannel(
                    $conversation
                ),

            'mode' =>
                $conversation->mode,

            'already_requested' =>
                $result[
                    'already_requested'
                ],
        ]);
    }

    /**
     * Find an existing website conversation without
     * creating one.
     */
    private function findWebsiteConversation(
        Website $website,
        string $visitorId
    ): ?Conversation {
        $visitorId =
            trim(
                $visitorId
            );

        try {
            $connection =
                $this
                    ->websiteConversationResolver
                    ->resolveConnection(
                        $website
                    );

            /*
             * WebsiteConversationResolver and WebsiteAdapter deliberately
             * preserve the raw website visitor ID as external_thread_id for
             * backwards compatibility with existing widget visitors.
             */
            $conversation =
                Conversation::query()
                    ->where(
                        'tenant_id',
                        $website->tenant_id
                    )
                    ->where(
                        'channel_connection_id',
                        $connection->id
                    )
                    ->where(
                        'external_thread_id',
                        $visitorId
                    )
                    ->orderByDesc('id')
                    ->first();

            if ($conversation) {
                return $conversation;
            }
        } catch (RuntimeException $exception) {
            Log::warning(
                'Website history omnichannel lookup fell back to legacy lookup.',
                [
                    'website_id' =>
                        $website->id,

                    'error' =>
                        $exception->getMessage(),
                ]
            );
        }

        /*
         * Legacy website lookup.
         */
        return Conversation::query()
            ->where(
                'website_id',
                $website->id
            )
            ->where(
                'visitor_id',
                $visitorId
            )
            ->orderBy('id')
            ->first();
    }

    /**
     * Website is attached to the request by
     * the existing embed-token middleware.
     */
    private function resolveWebsite(
        Request $request
    ): ?Website {
        return
            $request->website
            ??
            $request
                ->attributes
                ->get(
                    'website'
                );
    }

    /**
     * Existing website Reverb channel.
     */
    private function conversationChannel(
        Conversation $conversation
    ): ?string {
        if (
            !$conversation->realtime_token
        ) {
            return null;
        }

        return
            'conversation.'
            . $conversation->realtime_token;
    }

    /**
     * Preserve the JSON structure expected by
     * the existing website widget.
     */
    private function formatMessage(
        Message $message
    ): array {
        $message->loadMissing(
            'user'
        );

        return [
            'id' =>
                $message->id,

            'conversation_id' =>
                $message->conversation_id,

            'sender' =>
                $message->sender,

            'message' =>
                $message->message,

            'is_system' =>
                (bool)
                $message->is_system,

            'agent_name' =>
                $message->user?->name,

            'created_at' =>
                $message
                    ->created_at
                    ?->toISOString(),
        ];
    }
}
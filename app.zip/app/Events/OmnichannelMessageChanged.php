<?php

namespace App\Events;

use App\Models\Message;
use Carbon\CarbonInterface;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use RuntimeException;
use Throwable;

class OmnichannelMessageChanged implements ShouldBroadcastNow
{
    use Dispatchable;
    use InteractsWithSockets;
    use SerializesModels;

    public function __construct(
        public Message $message,
        public string $changeType = 'updated'
    ) {
        $this->message->loadMissing(
            'conversation'
        );

        if (!$this->message->conversation) {
            throw new RuntimeException(
                'Cannot broadcast an omnichannel message without a conversation.'
            );
        }
    }

    /**
     * Channels that receive this event.
     *
     * 1. Tenant inbox:
     *    Every authorized agent viewing the tenant inbox
     *    receives the event.
     *
     * 2. Conversation:
     *    Users actively viewing one conversation receive
     *    the same event.
     */
    public function broadcastOn(): array
    {
        $conversation =
            $this->message->conversation;

        return [
            new PrivateChannel(
                "tenant.{$conversation->tenant_id}.inbox"
            ),

            new PrivateChannel(
                "tenant.{$conversation->tenant_id}.conversation.{$conversation->id}"
            ),
        ];
    }

    /**
     * Event name used by Laravel Echo.
     *
     * Frontend:
     *
     * .listen(
     *     '.omnichannel.message.changed',
     *     ...
     * )
     */
    public function broadcastAs(): string
    {
        return 'omnichannel.message.changed';
    }

    /**
     * Data sent to the frontend.
     */
    public function broadcastWith(): array
    {
        $conversation =
            $this->message->conversation;

        return [
            'change_type' =>
                $this->changeType,

            'message' => [
                'id' =>
                    $this->message->id,

                'conversation_id' =>
                    $this->message->conversation_id,

                'channel_connection_id' =>
                    $this->message->channel_connection_id,

                'external_message_id' =>
                    $this->message->external_message_id,

                'direction' =>
                    $this->message->direction,

                'sender_type' =>
                    $this->message->sender_type,

                'message_type' =>
                    $this->message->message_type,

                'message' =>
                    $this->message->message,

                'status' =>
                    $this->message->status,

                'is_ai_generated' =>
                    (bool) $this->message
                        ->is_ai_generated,

                'sent_at' =>
                    $this->formatDate(
                        $this->message->sent_at
                    ),

                'created_at' =>
                    $this->formatDate(
                        $this->message->created_at
                    ),

                'updated_at' =>
                    $this->formatDate(
                        $this->message->updated_at
                    ),
            ],

            'conversation' => [
                'id' =>
                    $conversation->id,

                'tenant_id' =>
                    $conversation->tenant_id,

                'channel_connection_id' =>
                    $conversation
                        ->channel_connection_id,

                'contact_id' =>
                    $conversation->contact_id,

                'status' =>
                    $conversation->status,

                'mode' =>
                    $conversation->mode,

                'unread_count' =>
                    (int) $conversation
                        ->unread_count,

                'last_message_at' =>
                    $this->formatDate(
                        $conversation
                            ->last_message_at
                    ),

                'last_inbound_at' =>
                    $this->formatDate(
                        $conversation
                            ->last_inbound_at
                    ),

                'first_response_at' =>
                    $this->formatDate(
                        $conversation
                            ->first_response_at
                    ),
            ],
        ];
    }

    /**
     * Some of the omnichannel timestamp casts will be
     * finalized during the model/relationship step.
     *
     * Until then, this safely handles either Carbon
     * objects or raw database datetime strings.
     */
    private function formatDate(
        mixed $value
    ): ?string {
        if ($value === null || $value === '') {
            return null;
        }

        if ($value instanceof CarbonInterface) {
            return $value->toIso8601String();
        }

        try {
            return Carbon::parse(
                $value
            )->toIso8601String();
        } catch (Throwable) {
            return (string) $value;
        }
    }
}